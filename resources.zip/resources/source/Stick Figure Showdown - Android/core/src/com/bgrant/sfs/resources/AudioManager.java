package com.bgrant.sfs.resources;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Sound;

import java.util.ArrayList;

public class AudioManager {
    // settings
    private boolean musicEnabled = true;
    private boolean soundsEnabled = true;

    // music
    private final Sound music;
    private boolean musicPlaying = false;

    // UI sounds
    private final Sound clickSound;

    // game sounds
    private final Sound blockSound;
    private final Sound booSound;
    private final Sound cheerSound;
    private final Sound hitSound;
    private final ArrayList<Sound> allGameSounds;

    public AudioManager(AssetManager assetManager) {
        // get all audio assets from the asset manager
        music = assetManager.get(Assets.MUSIC);
        clickSound = assetManager.get(Assets.CLICK_SOUND);
        blockSound = assetManager.get(Assets.BLOCK_SOUND);
        booSound = assetManager.get(Assets.BOO_SOUND);
        cheerSound = assetManager.get(Assets.CHEER_SOUND);
        hitSound = assetManager.get(Assets.HIT_SOUND);

        // create an array list of all game sounds for easily pausing, resuming, and stopping them all at once
        allGameSounds = new ArrayList<>();
        allGameSounds.add(blockSound);
        allGameSounds.add(booSound);
        allGameSounds.add(cheerSound);
        allGameSounds.add(hitSound);
    }

    public void enableMusic() {
        // if music is already playing, don't do anything
        if (musicPlaying) return;

        // enable music
        musicEnabled = true;

        // loop music
        music.loop();
        musicPlaying = true;
    }

    public void disableMusic() {
        // disable music
        musicEnabled = false;

        // stop music
        music.stop();
        musicPlaying = false;
    }

    public void toggleMusic() {
        // enable or disable music
        if (musicEnabled) {
            disableMusic();
        } else {
            enableMusic();
        }
    }

    public void playMusic() {
        // if music is already playing, don't do anything
        if (musicPlaying) return;

        // if music is enabled, loop it
        if (musicEnabled) {
            music.loop();
            musicPlaying = true;
        }
    }

    public void stopMusic() {
        // if music is enabled, stop it
        if (musicEnabled) {
            music.stop();
            musicPlaying = false;
        }
    }

    public void enableSounds() {
        soundsEnabled = true;
    }

    public void disableSounds() {
        soundsEnabled = false;
    }

    public void playSound(String soundAsset) {
        // if sounds are enabled, play requested sound
        if (soundsEnabled) {
            switch (soundAsset) {
                case Assets.CLICK_SOUND:
                    clickSound.play();
                    break;
                case Assets.BLOCK_SOUND:
                    blockSound.play();
                    break;
                case Assets.BOO_SOUND:
                    booSound.play();
                    break;
                case Assets.CHEER_SOUND:
                    cheerSound.play();
                    break;
                case Assets.HIT_SOUND:
                    hitSound.play();
            }
        }
    }

    public void pauseGameSounds() {
        // pause any instances of game sounds
        for (Sound sound : allGameSounds) {
            sound.pause();
        }
    }

    public void resumeGameSounds() {
        // resume any instances of game sounds
        for (Sound sound : allGameSounds) {
            sound.resume();
        }
    }

    public void stopGameSounds() {
        // stop any instances of game sounds
        for (Sound sound : allGameSounds) {
            sound.stop();
        }
    }
}
